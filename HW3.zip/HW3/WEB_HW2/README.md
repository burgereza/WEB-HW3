# WEB_HW2
Sharif University Of Technology

MEMBERS:
    Hossein Sobhi 97106081
    Danial Barari 97110563
    Seyed Reza Ghamghaam - 99170542

Install the requirements using: 
`go get github.com/gin-contrib/sessions`
`go get github.com/gin-contrib/sessions/cookie`
`go get github.com/gin-gonic/gin`

To run the app use:
`go run ./...`

GO is live as long as you don't add or change handlers, so it doesn't require restart for changing assets/static files
