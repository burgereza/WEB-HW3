package models

type Ticket struct {
	Flight_serial string
	Flight_id     string
	Dest          string
	Price         string
	Aircraft      string
	Departure_utc string
	Duration      string
}
