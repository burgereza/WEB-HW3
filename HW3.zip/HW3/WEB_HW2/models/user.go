package models

type User struct {
	Username    string
	Password    string
	PhoneNumber string
}

// type Ticket struct {
// 	city1 string
// 	FlightNumber string

// }
